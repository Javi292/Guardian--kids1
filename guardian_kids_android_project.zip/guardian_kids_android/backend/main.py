import os
import json
import urllib.request
import urllib.error
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from safety_engine import analyze_message, public_result

load_dotenv()
app = FastAPI(title="Guardian Kids Core", version="0.3.0")
APP_TOKEN = os.getenv("APP_TOKEN", "")
AI_API_KEY = os.getenv("AI_API_KEY", "")
AI_BASE_URL = os.getenv("AI_BASE_URL", "").rstrip("/")
AI_MODEL = os.getenv("AI_MODEL", "")

SYSTEM_PROMPT = """
Eres NEO, un asistente educativo de IA para niños de 4 a 9 años.
Habla en español sencillo, cálido, breve y apropiado para la edad.
Di claramente que eres una inteligencia artificial, no una persona.
Nunca pidas nombre completo, dirección, ubicación, teléfono, contraseñas, fotos o secretos.
No promuevas violencia, sexualización, autolesiones, retos peligrosos ni contacto secreto.
No prometas guardar secretos ni confidencialidad absoluta.
Si el niño cuenta que alguien lo amenaza, pide fotos privadas o quiere verlo a escondidas,
dile con calma que no es su culpa, que deje de responder y que busque ahora a un adulto seguro.
No afirmes que notificaste a sus padres: solo un canal de notificación real puede hacerlo.
No sustituyas a sus cuidadores, profesionales o servicios de emergencia.
"""

class Message(BaseModel):
    message: str = Field(min_length=1, max_length=2000)

def authorize(authorization: str | None):
    if not APP_TOKEN or authorization != f"Bearer {APP_TOKEN}":
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.get("/health")
def health():
    return {"status": "ok", "ai_configured": bool(AI_API_KEY and AI_BASE_URL and AI_MODEL)}

@app.post("/safety-check")
def safety_check(body: Message, authorization: str | None = Header(default=None)):
    authorize(authorization)
    return public_result(analyze_message(body.message))

@app.post("/chat")
def chat(body: Message, authorization: str | None = Header(default=None)):
    authorize(authorization)
    safety = analyze_message(body.message)
    if safety.level in ("high", "medium"):
        return {"reply": safety.child_message, "mode": "safety", "safety_level": safety.level}

    if not (AI_API_KEY and AI_BASE_URL and AI_MODEL):
        return {
            "reply": "¡Qué buena pregunta! Ahora estoy en modo de aprendizaje local. "
                     "Podemos explorarlo juntos y pedir ayuda a un adulto si hace falta. ⭐",
            "mode": "fallback",
            "safety_level": "low"
        }

    payload = {
        "model": AI_MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": body.message}
        ],
        "temperature": 0.3,
        "max_tokens": 220
    }
    req = urllib.request.Request(
        AI_BASE_URL + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {AI_API_KEY}", "Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
        reply = data["choices"][0]["message"]["content"].strip()
        if not reply:
            raise ValueError("Empty response")
        return {"reply": reply[:1800], "mode": "ai", "safety_level": "low"}
    except (urllib.error.URLError, KeyError, ValueError, TimeoutError):
        raise HTTPException(status_code=502, detail="AI provider unavailable")
