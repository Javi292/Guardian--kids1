"""Motor inicial de reglas para seguridad infantil. No sustituye revisión humana."""
from dataclasses import dataclass, asdict
import re
import unicodedata
from typing import List

@dataclass
class SafetyResult:
    level: str
    categories: List[str]
    should_pause: bool
    child_message: str

def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-z0-9ñáéíóúü\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

RULES = {
    "private_images": [
        r"\bfoto(s)? (desnuda|intima|privada)s?\b",
        r"\bmanda(me)? una foto\b",
        r"\benseña(me)? tu cuerpo\b",
        r"\bvideo(s)? sin ropa\b",
    ],
    "personal_information": [
        r"\b(dime|manda|pasa) (tu )?(direccion|ubicacion|donde vives)\b",
        r"\bcomo te llamas completo\b",
        r"\bnumero de telefono\b",
    ],
    "passwords_or_accounts": [
        r"\b(contrasena|password|clave) (de|del|para)\b",
        r"\bdame tu contrasena\b",
        r"\bcodigo de verificacion\b",
    ],
    "forced_secrecy": [
        r"\bno le digas a (tus )?(padres|papa|mama)\b",
        r"\bque esto sea un secreto\b",
        r"\bno se lo cuentes a nadie\b",
    ],
    "threats_or_coercion": [
        r"\b(te voy a|voy a) (hacer dano|lastimar|golpear)\b",
        r"\bsi no haces esto\b",
        r"\bte voy a castigar\b",
    ],
    "secret_contact": [
        r"\bven (a verme|solo|sin tus padres)\b",
        r"\bencuentrame a escondidas\b",
        r"\bborra esta conversacion\b",
    ],
}

HIGH = {"private_images", "forced_secrecy", "threats_or_coercion", "secret_contact"}
MEDIUM = {"personal_information", "passwords_or_accounts"}

HIGH_MESSAGE = (
    "Eso puede ser peligroso y no es tu culpa. No envíes fotos, datos ni contraseñas. "
    "Deja de responder y cuéntaselo ahora a tu mamá, papá o a otro adulto de confianza. "
    "Si estás en peligro en este momento, busca a un adulto que esté cerca."
)
MEDIUM_MESSAGE = (
    "No compartas tu dirección, teléfono, contraseñas ni códigos. "
    "Pausa la conversación y consulta con tu mamá, papá o adulto de confianza."
)

def analyze_message(message: str) -> SafetyResult:
    normalized = normalize(message)
    categories = []
    for category, patterns in RULES.items():
        if any(re.search(pattern, normalized) for pattern in patterns):
            categories.append(category)

    if any(category in HIGH for category in categories):
        return SafetyResult("high", categories, True, HIGH_MESSAGE)
    if any(category in MEDIUM for category in categories):
        return SafetyResult("medium", categories, True, MEDIUM_MESSAGE)
    return SafetyResult(
        "low", [], False,
        "Sigamos aprendiendo. Recuerda que nunca tienes que compartir información privada."
    )

def public_result(result: SafetyResult) -> dict:
    # No devolver el texto original ni datos identificables en el resultado.
    return asdict(result)
