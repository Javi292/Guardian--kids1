plugins { id("com.android.application") }

android {
    namespace = "com.guardiankids.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.guardiankids.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.3.1"
    }
}
