# GUARDIÁN KIDS Android — proyecto base 0.3.1

Este paquete convierte la interfaz web del prototipo GUARDIÁN KIDS en una aplicación Android contenedora (WebView) y conserva el backend FastAPI por separado.

## Crear el APK
1. Instala Android Studio en una computadora.
2. Descomprime este ZIP y abre la carpeta `guardian_kids_android` como proyecto.
3. Espera a que Gradle sincronice y acepta instalar Android SDK Platform 35 si lo solicita.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

## Qué incluye y qué no
- Incluye la interfaz visual del prototipo (NEO, chat demostrativo, cuentos/actividades y panel parental visual) dentro de una app Android.
- Incluye el motor FastAPI y reglas de seguridad en `backend/`, como código fuente separado.
- La app Android todavía NO está conectada al backend. El chat de la interfaz sigue siendo demostrativo/local.
- No supervisa WhatsApp, SMS ni otras aplicaciones; no activa huella dactilar; no envía alertas reales; no es una IA conectada ni un control parental del sistema.
- No usar como protección real ni entregar a menores como producto terminado sin conectar el servidor, implementar autenticación/consentimiento, probar y auditar seguridad y privacidad.

## Requisitos
Android Studio reciente, JDK 17 y Android SDK Platform 35. El proyecto usa Android Gradle Plugin 8.7.3.
